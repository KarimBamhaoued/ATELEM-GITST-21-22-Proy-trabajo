package com.android.countdowntimer.home;

public interface EventItemActionListener {
    void onItemSwiped(String eventId);
    void onItemClicked(String eventId);
}
