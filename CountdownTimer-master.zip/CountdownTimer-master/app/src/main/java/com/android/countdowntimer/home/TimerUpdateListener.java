package com.android.countdowntimer.home;

public interface TimerUpdateListener {

    void onUpdateView(long duration);
}
