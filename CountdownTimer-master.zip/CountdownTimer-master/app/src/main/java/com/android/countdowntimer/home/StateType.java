package com.android.countdowntimer.home;

public class StateType {

    public static final int GONE = 0;
    public static final int ONGOING = 1;
    public static final int WAITING = 2;
    public static final int COMPLETED = 3;
}
