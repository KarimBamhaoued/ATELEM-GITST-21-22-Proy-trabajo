package com.android.countdowntimer.home;

public interface EventTouchHelperListener {

    void onItemSwipeToStart(int position);

}
